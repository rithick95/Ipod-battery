// BatteryInside - battery percentage drawn inside the stock iOS 9 status bar battery icon.
//
// How it works (kept deliberately small):
//  * hooks UIStatusBarBatteryItemView, the view UIKit uses for the battery icon
//    (SpringBoard, Lock Screen and every app status bar use this same class)
//  * after every battery update it reads the same capacity value Apple's own
//    "Battery Percentage" text uses (_capacity, exact 1% steps) and the charge state
//  * draws the number with one tiny transparent overlay view
//  * the icon's real position and colour are measured from the rendered icon,
//    so the number stays centred in every status bar style
//  * the part of the number over the filled bar is drawn in a contrast colour,
//    the part over the empty bar in the icon colour

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <QuartzCore/QuartzCore.h>

// ---- tuning knobs (points) -------------------------------------------------
static const CGFloat kNubWidth     = 2.0;   // width of the little contact on the right of the battery
static const CGFloat kInnerInsetX  = 2.0;   // distance from the outline to the fill, left and right
static const CGFloat kInnerInsetY  = 2.0;   // distance from the outline to the fill, top and bottom
static const CGFloat kFontSize2    = 8.5;   // font size for 1-2 digits
static const CGFloat kFontSize3    = 7.0;   // font size for "100"
// ----------------------------------------------------------------------------

@interface UIStatusBarItemView : UIView
@end

@interface UIStatusBarBatteryItemView : UIStatusBarItemView
@end

@interface UIStatusBarBatteryItemView (PCB)
- (void)pcb_refresh;
@end

static char kViewKey;
static char kBusyKey;
static char kLastKey;
static char kGeoKey;

#pragma mark - small helpers

static int pcbReadInt(id obj, const char *name, int def) {
    Ivar iv = class_getInstanceVariable(object_getClass(obj), name);
    if (!iv) return def;
    return *(int *)((char *)(__bridge void *)obj + ivar_getOffset(iv));
}

static BOOL pcbReadBool(id obj, const char *name, BOOL def) {
    Ivar iv = class_getInstanceVariable(object_getClass(obj), name);
    if (!iv) return def;
    return *(unsigned char *)((char *)(__bridge void *)obj + ivar_getOffset(iv)) ? YES : NO;
}

static CGFloat pcbLuminance(UIColor *c) {
    if (!c) return 1.0;
    CGColorRef cg = c.CGColor;
    size_t n = CGColorGetNumberOfComponents(cg);
    const CGFloat *p = CGColorGetComponents(cg);
    if (n >= 3) return 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2];
    return p[0];
}

#pragma mark - overlay view

@interface PCBTextView : UIView
@property (nonatomic, assign) int capacity;
@property (nonatomic, assign) BOOL plugged;
@property (nonatomic, assign) BOOL lowPower;
@property (nonatomic, strong) UIColor *tint;
@property (nonatomic, assign) CGRect inner;     // battery interior, in this view's coordinates
@property (nonatomic, assign) CGFloat centerY;  // vertical centre of the battery body
@end

@implementation PCBTextView

- (UIColor *)onFillColor {
    UIColor *dark = [UIColor colorWithWhite:0.08 alpha:1.0];
    if (self.lowPower) return dark;                 // yellow fill
    if (self.plugged) return dark;                  // green fill
    if (self.capacity <= 20) return [UIColor whiteColor]; // red fill
    return pcbLuminance(self.tint) > 0.5 ? dark : [UIColor whiteColor];
}

- (void)drawRect:(CGRect)rect {
    if (self.capacity < 0 || self.capacity > 100) return;
    NSString *s = [NSString stringWithFormat:@"%d", self.capacity];
    CGFloat size = s.length >= 3 ? kFontSize3 : kFontSize2;
    UIFont *font = nil;
    if ([UIFont respondsToSelector:@selector(monospacedDigitSystemFontOfSize:weight:)]) {
        font = [UIFont monospacedDigitSystemFontOfSize:size weight:UIFontWeightBold];
    }
    if (!font) font = [UIFont boldSystemFontOfSize:size];

    CGRect in = self.inner;
    CGSize ts = [s sizeWithAttributes:@{NSFontAttributeName: font}];
    CGFloat scale = [UIScreen mainScreen].scale;
    if (scale < 1) scale = 1;
    CGFloat x = in.origin.x + (in.size.width - ts.width) / 2.0;
    CGFloat y = self.centerY + font.capHeight / 2.0 - font.ascender;
    x = round(x * scale) / scale;
    y = round(y * scale) / scale;
    CGPoint origin = CGPointMake(x, y);

    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGFloat fillW = in.size.width * (CGFloat)self.capacity / 100.0;
    CGRect fillRect = CGRectMake(in.origin.x - 1, in.origin.y - 2, fillW + 1, in.size.height + 4);
    CGRect emptyRect = CGRectMake(in.origin.x + fillW, in.origin.y - 2, in.size.width - fillW + 1, in.size.height + 4);

    NSDictionary *onFill = @{NSFontAttributeName: font, NSForegroundColorAttributeName: [self onFillColor]};
    NSDictionary *onEmpty = @{NSFontAttributeName: font, NSForegroundColorAttributeName: self.tint ? self.tint : [UIColor whiteColor]};

    if (self.capacity > 0) {
        CGContextSaveGState(ctx);
        CGContextClipToRect(ctx, fillRect);
        [s drawAtPoint:origin withAttributes:onFill];
        CGContextRestoreGState(ctx);
    }
    if (self.capacity < 100) {
        CGContextSaveGState(ctx);
        CGContextClipToRect(ctx, emptyRect);
        [s drawAtPoint:origin withAttributes:onEmpty];
        CGContextRestoreGState(ctx);
    }
}

@end

#pragma mark - measuring the real icon

// Renders the item view once into a tiny bitmap, finds where the icon really is and what colour
// its outline has. Cheap (about 50x22 pixels) and only done when the battery data changes.
static BOOL pcbMeasure(UIView *v, CGRect *bbox, UIColor **tint) {
    CGSize sz = v.bounds.size;
    if (sz.width < 6 || sz.height < 6 || sz.width > 200 || sz.height > 100) return NO;
    CGFloat sc = [UIScreen mainScreen].scale;
    if (sc < 1) sc = 1;
    size_t w = (size_t)ceil(sz.width * sc);
    size_t h = (size_t)ceil(sz.height * sc);
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
    CGContextRef ctx = CGBitmapContextCreate(NULL, w, h, 8, w * 4, cs, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(cs);
    if (!ctx) return NO;
    CGContextTranslateCTM(ctx, 0, (CGFloat)h);
    CGContextScaleCTM(ctx, sc, -sc);
    [v.layer renderInContext:ctx];
    const uint8_t *px = (const uint8_t *)CGBitmapContextGetData(ctx);
    BOOL ok = NO;
    long minC = (long)w, maxC = -1, minR = (long)h, maxR = -1;
    if (px) {
        for (size_t r = 0; r < h; r++) {
            for (size_t c = 0; c < w; c++) {
                if (px[(r * w + c) * 4 + 3] > 60) {
                    if ((long)c < minC) minC = (long)c;
                    if ((long)c > maxC) maxC = (long)c;
                    if ((long)r < minR) minR = (long)r;
                    if ((long)r > maxR) maxR = (long)r;
                }
            }
        }
        if (maxC >= 0 && maxR >= 0) {
            *bbox = CGRectMake(minC / sc, minR / sc, (maxC - minC + 1) / sc, (maxR - minR + 1) / sc);
            ok = YES;
            // outline colour: leftmost pixel of the icon, middle row
            long mr = (minR + maxR) / 2;
            const uint8_t *p = px + ((size_t)mr * w + (size_t)minC) * 4;
            CGFloat a = p[3] / 255.0;
            if (a > 0.2) {
                *tint = [UIColor colorWithRed:MIN(1.0, p[0] / 255.0 / a)
                                        green:MIN(1.0, p[1] / 255.0 / a)
                                         blue:MIN(1.0, p[2] / 255.0 / a)
                                        alpha:1.0];
            }
        }
    }
    CGContextRelease(ctx);
    return ok;
}

#pragma mark - hook

%hook UIStatusBarBatteryItemView

- (BOOL)updateForNewData:(id)data actions:(int)actions {
    BOOL r = %orig;
    [self pcb_refresh];
    return r;
}

- (void)layoutSubviews {
    %orig;
    [self pcb_refresh];
}

- (void)didMoveToWindow {
    %orig;
    [self pcb_refresh];
}

%new
- (void)pcb_refresh {
    if (objc_getAssociatedObject(self, &kBusyKey)) return;      // no re-entrancy
    objc_setAssociatedObject(self, &kBusyKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    int cap = pcbReadInt(self, "_capacity", -1);
    int state = pcbReadInt(self, "_state", 0);
    BOOL lpm = pcbReadBool(self, "_batterySaverModeActive", NO);
    if (!lpm && [[NSProcessInfo processInfo] respondsToSelector:@selector(isLowPowerModeEnabled)]) {
        lpm = [[NSProcessInfo processInfo] isLowPowerModeEnabled];
    }
    if (cap < 0 || cap > 100) {
        UIDevice *d = [UIDevice currentDevice];
        d.batteryMonitoringEnabled = YES;
        float lvl = d.batteryLevel;
        cap = lvl >= 0 ? (int)lroundf(lvl * 100.0f) : -1;
    }

    // skip the work when nothing changed in the last moment
    NSString *key = [NSString stringWithFormat:@"%d|%d|%d|%.0fx%.0f", cap, state, lpm, self.bounds.size.width, self.bounds.size.height];
    NSDictionary *last = objc_getAssociatedObject(self, &kLastKey);
    double now = CACurrentMediaTime();
    if (last && [last[@"k"] isEqualToString:key] && now - [last[@"t"] doubleValue] < 0.25) {
        objc_setAssociatedObject(self, &kBusyKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return;
    }
    objc_setAssociatedObject(self, &kLastKey, @{@"k": key, @"t": @(now)}, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    PCBTextView *tv = objc_getAssociatedObject(self, &kViewKey);
    if (!tv) {
        tv = [[PCBTextView alloc] initWithFrame:self.bounds];
        tv.userInteractionEnabled = NO;
        tv.opaque = NO;
        tv.backgroundColor = [UIColor clearColor];
        objc_setAssociatedObject(self, &kViewKey, tv, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (tv.superview != self) [self addSubview:tv];
    if (!CGRectEqualToRect(tv.frame, self.bounds)) tv.frame = self.bounds;
    [self bringSubviewToFront:tv];

    // the charging bolt is a separate subview; hide it while measuring so it cannot change the result
    Ivar aiv = class_getInstanceVariable(object_getClass(self), "_accessoryView");
    UIView *acc = aiv ? object_getIvar(self, aiv) : nil;
    if (![acc isKindOfClass:[UIView class]]) acc = nil;
    BOOL accWasHidden = acc ? acc.hidden : NO;
    if (acc) acc.hidden = YES;
    BOOL tvWasHidden = tv.hidden;
    tv.hidden = YES;

    CGRect bbox = CGRectZero;
    UIColor *tint = nil;
    BOOL ok = pcbMeasure(self, &bbox, &tint);

    tv.hidden = tvWasHidden;
    if (acc) acc.hidden = accWasHidden;

    NSValue *geo = objc_getAssociatedObject(self, &kGeoKey);
    if (ok && bbox.size.width > 10 && bbox.size.height > 5) {
        geo = [NSValue valueWithCGRect:bbox];
        objc_setAssociatedObject(self, &kGeoKey, geo, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    CGRect icon = geo ? [geo CGRectValue] : CGRectMake(0, (self.bounds.size.height - 11) / 2, MIN(25, self.bounds.size.width), 11);

    CGRect body = CGRectMake(icon.origin.x, icon.origin.y, icon.size.width - kNubWidth, icon.size.height);
    CGRect inner = CGRectInset(body, kInnerInsetX, kInnerInsetY);

    tv.capacity = cap;
    tv.plugged = state != 0;
    tv.lowPower = lpm;
    if (tint) tv.tint = tint;
    tv.inner = inner;
    tv.centerY = CGRectGetMidY(body);
    tv.hidden = (cap < 0);
    [tv setNeedsDisplay];

    // keep the stock charging bolt only when it does not sit on top of the number
    if (acc && CGRectIntersectsRect(acc.frame, CGRectInset(inner, 1, -2))) {
        acc.hidden = YES;
    }

    objc_setAssociatedObject(self, &kBusyKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

%end
